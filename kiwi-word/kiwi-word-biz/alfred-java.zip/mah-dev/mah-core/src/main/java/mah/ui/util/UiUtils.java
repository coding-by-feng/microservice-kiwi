/**
 * MIT License
 *
 * Copyright (c) 2017 zgqq
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package mah.ui.util;

import mah.ui.key.KeystateManager;
import mah.ui.layout.Layout;
import mah.ui.pane.input.InputPane;
import mah.ui.pane.input.InputPaneProvider;
import mah.ui.window.WindowManager;
import org.jetbrains.annotations.Nullable;

/**
 * Created by zgq on 2017-01-12 11:17
 */
public final class UiUtils {
    private UiUtils(){}

    public static void hideWindow() {
        KeystateManager.getInstance().reset();
        WindowManager.getInstance().getCurrentWindow().hide();
    }

    @Nullable
    public static InputPane getInputPane() {
        Layout currentLayout = WindowManager.getInstance().getCurrentWindow().getCurrentLayout();
        if (currentLayout instanceof InputPaneProvider) {
            InputPaneProvider layout = (InputPaneProvider) currentLayout;
            return layout.getInputPane();
        }
        return null;
    }
}
